﻿using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DMS_Models.AWSS3
{
    public class AddTag
    {
        [Required]
        [SwaggerSchema(description : "AWS S3 Bucket Name")]
        public string BucketName { get; set; }
        
        [Required]
        public List<Tag> Tags { get; set; }
    }

    public class Tag
    {
        [Required]
        [SwaggerSchema(description : "AWS S3 Bucket Tag key")]
        public string key { get; set; }

        [Required]
        [SwaggerSchema(description : "AWS S3 Bucket Tag Value")]
        public string Value { get; set; }
    }
}