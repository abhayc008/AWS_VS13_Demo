﻿using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DMS_Models
{
    public class ResponseResult
    {
        [SwaggerSchema(description:"True or False")]
        public bool Error { get; set; }

        [SwaggerSchema(description: "Error Message")]
        public string ErrorMessage { get;set;}

        [SwaggerSchema(description: "API response data")]
        public object Data { get; set; }
    }
}