using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DMS_Models
{
    public class GlobalSearch
    {
        [SwaggerSchema(description: "File Name to be search in AWS S3 or SharePoint")]
        public string fileName { get; set; } = string.Empty;

        [SwaggerSchema(description: "File extension, only when target is SharePoint")]
        public string fileExtension { get; set; } = string.Empty;
    }
}                                                                                                                                                                                                                                                                         