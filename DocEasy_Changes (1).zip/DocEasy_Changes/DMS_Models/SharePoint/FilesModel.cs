﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS_Models.SharePoint
{
    public class FilesModel
    {
        public string Name { get; set; }
        public string ServerRelativeUrl { get; set; }
        public string DisplayPath { get; set; }
        public DateTime TimeCreated { get; set; }
        public DateTime TimeLastModified { get; set; }
    }
}
