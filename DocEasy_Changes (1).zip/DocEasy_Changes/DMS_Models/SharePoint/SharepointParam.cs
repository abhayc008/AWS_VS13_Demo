﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DMS_Models.SharePoint
{
    public class SharepointParam
    {
        public string sharepointaaccessurl { get; set; }
        public string tenantid { get; set; }
        public string grant_type { get; set; }
        public string client_id { get; set; }
        public string client_secret { get; set; }
        public string resource { get; set; }
        public string access_token { get; set; }
        public string expires_in { get; set; }
        public string token_type { get; set; }
        public string expires_on { get; set; }
        public string sitedomain { get; set; }
        public string ServerRelativeUrl { get; set; }
        public string loginurl { get; set; }
        public string filepath { get; set; }
        public string filename { get; set; }
        public string RelativeAttchmntPath { get; set; }
    }
}