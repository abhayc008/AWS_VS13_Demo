﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS_Models.SharePoint
{
    public class GlobalSearchModel
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string Path { get; set; }
        public string LastModifiedTime { get; set; }
        public string OriginalPath { get; set; }
        public string SiteName { get; set; }
    }
}
