﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DMS_Models
{
    public static class LogToFile
    {
        public static void LogError(Exception ex, string FunctionName, string file_Name = "")
        {

            string wwwPath = Path.Combine(Environment.CurrentDirectory, "Log");

            if (!Directory.Exists(wwwPath))
                Directory.CreateDirectory(wwwPath);

            string dir1 = Path.Combine(wwwPath, "ExceptionLog");

            if (!Directory.Exists(dir1))
                Directory.CreateDirectory(dir1);

            string FinalPath = dir1 + "\\" + (string.IsNullOrEmpty(file_Name) ? Convert.ToString(DateTime.Now.ToString("dd-MM-yyyy")) + ".txt" : file_Name + ".txt");

            if (!File.Exists(FinalPath))
                File.Create(FinalPath).Dispose();

            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            message += string.Format("Function: {0}", FunctionName);
            message += Environment.NewLine;
            message += string.Format("Message: {0}", ex.Message);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", ex.StackTrace);
            message += Environment.NewLine;
            message += string.Format("Source: {0}", ex.Source);
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;

            using (StreamWriter writer = new StreamWriter(FinalPath, true))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }

        public static bool LogRequest(ApiLogItem1 obj)
        {
            try
            {
                string wwwPath = Path.Combine(Environment.CurrentDirectory, "Log");

                if (!Directory.Exists(wwwPath))
                    Directory.CreateDirectory(wwwPath);

                string dir1 = Path.Combine(wwwPath, "RequestLog");

                if (!Directory.Exists(dir1))
                    Directory.CreateDirectory(dir1);

                string FinalPath = dir1 + "\\" + Convert.ToString(DateTime.Now.ToString("dd-MM-yyyy")) + ".txt";

                if (!File.Exists(FinalPath))
                    File.Create(FinalPath).Dispose();

                string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                message += string.Format("Path: {0}", obj.Path);
                message += Environment.NewLine;
                message += string.Format("Method: {0}", obj.Method);
                message += Environment.NewLine;
                message += string.Format("QueryString: {0}", obj.QueryString);
                message += Environment.NewLine;
                message += string.Format("RequestTime: {0}", obj.RequestTime);
                message += Environment.NewLine;
                message += string.Format("StatusCode: {0}", obj.StatusCode);
                message += Environment.NewLine;
                message += string.Format("ResponseMillis: {0}", obj.ResponseMillis);
                message += Environment.NewLine;
                message += string.Format("RequestBody: {0}", obj.RequestBody);
                message += Environment.NewLine;
                message += string.Format("ResponseBody: {0}", obj.ResponseBody);
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;

                using (StreamWriter writer = new StreamWriter(FinalPath, true))
                {
                    writer.WriteLine(message);
                    writer.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public class ApiLogItem1
        {
            public long Id { get; set; }

            public DateTime RequestTime { get; set; }

             public long ResponseMillis { get; set; }

            public int StatusCode { get; set; }

            public string Method { get; set; }

             public string Path { get; set; }

            public string QueryString { get; set; }

            public string RequestBody { get; set; }

            public string ResponseBody { get; set; }
        }
    }
}
