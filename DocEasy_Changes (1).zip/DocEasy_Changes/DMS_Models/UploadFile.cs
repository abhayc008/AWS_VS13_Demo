﻿using Microsoft.AspNetCore.Http;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DMS_Models
{
    public class UploadFile
    {
        [Required]
        [SwaggerSchema(description:"AWS S3 Bucket Name or SharePoint Document Library")]
        public string bucketLibrary { get; set; }

        [SwaggerSchema(description: "Folder path")]
        public string folderPath { get; set; }

        [SwaggerSchema(description: "File content")]
        public IFormFile file { get; set; }

    }
}
