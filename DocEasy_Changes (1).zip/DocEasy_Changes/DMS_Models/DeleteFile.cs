﻿using Microsoft.AspNetCore.Http;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DMS_Models
{
    public class DeleteFile
    {
        [SwaggerSchema(description: "AWS S3 bucket Name, required only when target is AWS S3")]
        public string bucketName { get; set; } = string.Empty;


        [Required]
        [SwaggerSchema(description: "File Path in AWS S3 or SharePoint")]
        public string filePath { get; set; } = string.Empty;

    }
}
