using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DMS_Models
{
    public class SearchByFolder
    {
        [SwaggerSchema(description: "AWS S3 bucket Name or SharePoint LibraryName")]
        public string bucketLibrary { get; set; } = string.Empty;


        [Required]
        [SwaggerSchema(description: "Folder Path to be serch for files")]
        public string folderPath { get; set; } = string.Empty;
    }
}                                                                                                                                                                                                                                                                         