﻿using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Text;

namespace DMS_Models
{
   public class DocumentLibrary
    {
        [SwaggerSchema(description:"Date of creation of the bucket/Site")]
        public string creationDate { get; set; }

        [SwaggerSchema(description: "Name of S3 bucket or Sharepoint Document Library")]
        public string bucketLibrary { get; set; }
    }
}
