﻿using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AWSS3DMSLibrary.Repositories
{
    public interface IAwsClient
    {
        Task<IEnumerable<S3Bucket>> GetBucketsAsync(string S3RegionName, string AccessKey, string SecretKey);
        Task<PutBucketResponse> CreateBucketAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey);
        Task<DeleteBucketResponse> DeleteBucketAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey);
        Task<PutObjectResponse> UploadFile(string bucketName, Stream inputStream, string folderName, string fileNameWithExtension, string S3RegionName, string AccessKey, string SecretKey);
        Task<GetObjectResponse> DownloadFile(string fileName, string bucketName, string S3RegionName, string AccessKey, string SecretKey);
        Task<IEnumerable<S3Object>> GlobalSearchAsync(string docToSearch, string S3RegionName, string AccessKey, string SecretKey);
        Task<IEnumerable<S3Object>> GetAllObjectsAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey);
        Task<IEnumerable<S3Object>> GetAllObjectsByFolderAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey, string FolderPath);
        Task<PutBucketTaggingResponse> PutBucketTaggingAsync(string bucketName, List<Tag> tags, string S3RegionName, string AccessKey, string SecretKey);
        Task<GetBucketTaggingResponse> GetBucketTaggingAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey);
        Task<DeleteBucketTaggingResponse> DeleteBucketTaggingAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey);
    }
}
