﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWSS3DMSLibrary.Repositories
{
    public class AwsArchiveTransferManager
    {
        public AwsArchiveTransferManager()
        {
        }
    }
}
