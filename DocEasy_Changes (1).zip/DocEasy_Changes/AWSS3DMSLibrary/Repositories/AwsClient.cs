﻿using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AWSS3DMSLibrary.Factory;
using System.IO;
using AWSS3DMSLibrary.Constants;

namespace AWSS3DMSLibrary.Repositories
{
    public sealed class AwsClient : IAwsClient
    {
        private IAmazonS3 client;

        public async Task<PutBucketResponse> CreateBucketAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);
            var resp = await client.PutBucketAsync(new PutBucketRequest()
            {
                BucketName = bucketName,
                BucketRegion = AwsConstant.s3Region
            }).ConfigureAwait(false);
            return resp;
        }

        public async Task<DeleteBucketResponse> DeleteBucketAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            return await client.DeleteBucketAsync(bucketName).ConfigureAwait(false);
        }

        public async Task<IEnumerable<S3Bucket>> GetBucketsAsync(string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var resp = await client.ListBucketsAsync().ConfigureAwait(false);
            var res = Task.FromResult<IEnumerable<S3Bucket>>(resp.Buckets).ConfigureAwait(false);
            return await res;
        }

        public async Task<PutObjectResponse> UploadFile(string bucketName, Stream inputStream, string folderName, string fileNameWithExtension, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value, AccessKey, SecretKey);

            var req = new PutObjectRequest()
            {
                BucketName = bucketName + (string.IsNullOrEmpty(folderName) ? "" : "/" + folderName),
                InputStream = inputStream,
                Key = fileNameWithExtension,

            };
            var res = client2.PutObjectAsync(req).ConfigureAwait(false);
            client2 = null;
            return await res;
        }

        public async Task<GetObjectResponse> DownloadFile(string fileName, string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value, AccessKey, SecretKey);

            var req = new GetObjectRequest()
            {
                BucketName = bucketName,
                Key = fileName
            };

            //var allFiles = await client.ListObjectsAsync(bucketName).ConfigureAwait(false);
            var res = client2.GetObjectAsync(req).ConfigureAwait(false);

            return await res;
        }

        public async Task<DeleteObjectResponse> DeleteFile(string fileName, string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value, AccessKey, SecretKey);

            var req = new DeleteObjectRequest()
            {
                BucketName = bucketName,
                Key = fileName
            };

            //var allFiles = await client.ListObjectsAsync(bucketName).ConfigureAwait(false);
            var res = client2.DeleteObjectAsync(req).ConfigureAwait(false);

            return await res;
        }

        public async Task<IEnumerable<S3Object>> GlobalSearchAsync(string docToSearch, string S3RegionName, string AccessKey, string SecretKey)
        {
            var allBuckets = await GetBucketsAsync(S3RegionName, AccessKey, SecretKey).ConfigureAwait(false);
            var data = new List<S3Object>();
            foreach (var item in allBuckets)
            {
                data.AddRange(await GetAllObjectsAsync(item.BucketName, S3RegionName, AccessKey, SecretKey).ConfigureAwait(false));
            }

            return await Task.FromResult<IEnumerable<S3Object>>(data.Where(x => x.Key.ToUpperInvariant().Contains(docToSearch.ToUpperInvariant()))).ConfigureAwait(false);
        }

        public async Task<IEnumerable<S3Object>> GetAllObjectsAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value, AccessKey, SecretKey);
            var resp = await client2.ListObjectsV2Async(new ListObjectsV2Request() { BucketName = bucketName }, new CancellationToken()).ConfigureAwait(false);
            var res = Task.FromResult<IEnumerable<S3Object>>(resp.S3Objects).ConfigureAwait(false);
            client2 = null;
            return await res;
        }

        public async Task<IEnumerable<S3Object>> GetAllObjectsByFolderAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey, string FolderPath)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value, AccessKey, SecretKey);
            var resp = await client2.ListObjectsV2Async(new ListObjectsV2Request() { BucketName = bucketName }, new CancellationToken()).ConfigureAwait(false);
            var res = Task.FromResult<IEnumerable<S3Object>>(resp.S3Objects).ConfigureAwait(false);
            client2 = null;
            return await res;
        }

        public async Task<PutBucketTaggingResponse> PutBucketTaggingAsync(string bucketName, List<Tag> tags, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var res = await client.PutBucketTaggingAsync(bucketName, tags, new CancellationToken()).ConfigureAwait(false);
            return res;
        }

        public async Task<GetBucketTaggingResponse> GetBucketTaggingAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var res = await client.GetBucketTaggingAsync(new GetBucketTaggingRequest() { BucketName = bucketName }, new CancellationToken()).ConfigureAwait(false);
            return res;
        }

        public async Task<DeleteBucketTaggingResponse> DeleteBucketTaggingAsync(string bucketName, string S3RegionName, string AccessKey, string SecretKey)
        {
            client = S3ClientFactory.GetS3Client(S3RegionName, AccessKey, SecretKey);

            var res = await client.DeleteBucketTaggingAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            return res;
        }
    }
}
