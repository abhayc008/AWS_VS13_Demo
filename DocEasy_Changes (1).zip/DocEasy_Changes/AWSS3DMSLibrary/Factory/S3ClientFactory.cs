﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
// using System;
// using System.Collections.Generic;
// using System.Linq;
using System.Net;
// using System.Threading.Tasks;
using AWSS3DMSLibrary.Constants;

namespace AWSS3DMSLibrary.Factory
{
    public static class S3ClientFactory
    {

        public static AmazonS3Client GetS3Client(string systemName, string AccessKey,string SecretKey)
        {
            var regionEndPoint = RegionEndpoint.GetBySystemName(systemName);

            var config = new AmazonS3Config
            {   
                RegionEndpoint = regionEndPoint
            };
            config.SetWebProxy(new WebProxy("http://zia.edelcap.com:80"));
            return new AmazonS3Client(new BasicAWSCredentials(AccessKey, SecretKey), config);
        }
    }
}
