﻿using Amazon;
using Amazon.S3;

namespace AWSS3DMSLibrary.Constants
{
    public static class AwsConstant
    {
        public static readonly string Web_AccessKey = "AKIA5VEKB3TMO4T24ZPO";
        public static readonly string Web_SecretKey = "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";
        public static readonly RegionEndpoint regionEndpoint = RegionEndpoint.APSouth1;
        public static readonly S3Region s3Region = S3Region.APS3;
        public static readonly string DefaultS3Region = "ap-south-1";
    }
}
