﻿using DMS_Models;
using DMS_Models.SharePoint;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Xml;
using SharePointDMSLibrary;
using SharePointDMSLibrary.Models;

namespace SharePointDMSLibrary
{
    public static class Services
    {
        private static SharepointResponce objSharepointResponce = new SharepointResponce();

        private static List<FilesModel> lstFiles = new List<FilesModel>();

        #region Sharepoint Login
        public static ResponseResult GetAccessToken()
        {
            ResponseResult result = new ResponseResult();
            SharepointResponce objResult = new SharepointResponce();
            try
            {
                var client_id = ConfigurationManager.AppSettings["dms_client_id"];
                var client_secret = ConfigurationManager.AppSettings["dms_client_secret"];
                var tenantid = ConfigurationManager.AppSettings["dms_tenantid"];
                var loginurl = ConfigurationManager.AppSettings["dms_loginurl"];
                var resource = ConfigurationManager.AppSettings["dms_resource"];
                var sitedomain = ConfigurationManager.AppSettings["dms_sitedomain"];

                var postData = "grant_type=client_credentials";
                postData += "&client_id=" + client_id + "@" + tenantid;
                postData += "&client_secret=" + client_secret;
                postData += "&resource=" + resource + "/" + sitedomain + "@" + tenantid;
                APICall objApiCall = new APICall();
                List<APIParameters> lstParameter = new List<APIParameters>();
                byte[] data = Encoding.ASCII.GetBytes(postData);
                string url = loginurl.Replace("$#tenantid#$", tenantid);
                string response = objApiCall.MyHttpWebRequest(url, lstParameter, "application/x-www-form-urlencoded", "", "Post", data);

                objResult = JsonConvert.DeserializeObject<SharepointResponce>(response);
                if (objResult != null)
                {
                    var sharepointaaccessurl = ConfigurationManager.AppSettings["dms_sharepointaaccessurl"];
                    var SharePointSite = ConfigurationManager.AppSettings["dms_SharePointSite"];
                    var DocumentLibrary = ConfigurationManager.AppSettings["dms_DocumentLibrary"];

                    objResult.sharepointaaccessurl = sharepointaaccessurl;
                    objResult.SharePointSite = SharePointSite;
                    objResult.DocumentLibrary = DocumentLibrary;

                    objSharepointResponce = objResult;
                }
                result.Error = false;
                result.Data = objSharepointResponce;
                result.ErrorMessage = string.Empty;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }
        #endregion

        #region SharePoint Folder Operations
        // Create Folder in SharePoint
        public static ResponseResult SharePointCreateFolder(string DocumentLibrary, string FolderFullPath, string ParentFolder)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                FolderFullPath = FolderFullPath.Replace("\\", "/").Replace("//", "/");

                SharePointCreateInternalFolder(DocumentLibrary, FolderFullPath, ParentFolder);

                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Create folder hierarchy
        public static string SharePointCreateInternalFolder(string DocumentLibrary, string fullFolderPath, string parentFolder)
        {
            try
            {
                string response = "";

                var folderUrls = fullFolderPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

                JToken jtoken = new JObject();
                JToken jtoken_type = new JObject();

                //jtoken_type["type"] = "SP.Folder";        // Was Cause 400 Bad Request so commented
                //jtoken["__metadata"] = jtoken_type;

                jtoken["ServerRelativeUrl"] = "/" + objSharepointResponce.SharePointSite + "/" + DocumentLibrary + (!string.IsNullOrEmpty(parentFolder) ? parentFolder : string.Empty) + "/" + folderUrls[0];


                string digest = GetFormDigestValue();

                var json_string = Newtonsoft.Json.JsonConvert.SerializeObject(jtoken);

                APICall objApiCall = new APICall();

                List<APIParameters> lstParameters = new List<APIParameters>();
                lstParameters.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });
                lstParameters.Add(new APIParameters() { PropertyName = "X-RequestDigest", PropertyValue = digest });

                byte[] data = Encoding.ASCII.GetBytes(json_string);

                string url = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/folders";

                response = objApiCall.MyHttpWebRequest(url, lstParameters, "application/json", "application/json;odata=verbose", "Post", data);

                if (folderUrls.Length > 1)
                {
                    var subFolderUrl = string.Join("/", folderUrls, 1, folderUrls.Length - 1);
                    parentFolder += "/" + folderUrls[0];
                    return SharePointCreateInternalFolder(DocumentLibrary, subFolderUrl, parentFolder);
                }

                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Check folder existence
        public static string SharePointFolderExists(string DocumentLibrary, string FolderPath)
        {
            try
            {
                FolderPath = FolderPath.Replace("\\", "/").Replace("//", "/");

                APICall objApiCall = new APICall();

                List<APIParameters> lstParameter = new List<APIParameters>();
                lstParameter.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });

                string url = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/getfolderbyserverrelativeurl('"
                    + "/" + objSharepointResponce.SharePointSite + "/" + DocumentLibrary + "/" +
                    (string.IsNullOrEmpty(FolderPath) ? "" : (FolderPath + "/")) + "')";

                string response = objApiCall.MyHttpWebRequest(url, lstParameter, "", "application/json;odata=verbose", "Get", null);

                return response;
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        #endregion SharePoint Folder Operations

        #region SharePoint File Operations
        // Upload Files in Sharepoint
        public static ResponseResult UploadFile(string DocumentLibrary, byte[] FileData, string FileName, string FolderPath)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                APICall objApiCall = new APICall();

                List<APIParameters> lstParameters = new List<APIParameters>();

                APIParameters objApiParameter = new APIParameters();

                objApiParameter.PropertyName = "Authorization";
                objApiParameter.PropertyValue = "Bearer " + objSharepointResponce.access_token;

                lstParameters.Add(objApiParameter);

                objApiParameter = new APIParameters();
                objApiParameter.PropertyName = "IF-MATCH";
                objApiParameter.PropertyValue = "*";

                lstParameters.Add(objApiParameter);

                string digest = GetFormDigestValue();

                lstParameters.Add(new APIParameters() { PropertyName = "X-RequestDigest", PropertyValue = digest });

                string folderdata = SharePointFolderExists(DocumentLibrary, FolderPath);
                if (folderdata == "")
                {
                    ResponseResult resultCreateFolder = SharePointCreateFolder(DocumentLibrary, FolderPath, "");
                    if (resultCreateFolder.Error)
                        return resultCreateFolder;
                }
                else
                {
                    FolderPath = FolderPath.Replace("\\", "/").Replace("//", "/");
                }

                string url = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite
                                + "/_api/web/GetFolderByServerRelativeUrl('/"
                                + objSharepointResponce.SharePointSite
                                + "/" + DocumentLibrary
                                + (string.IsNullOrEmpty(FolderPath) ? "" : "/" + FolderPath)
                                + "/')/Files/add(url='" + FileName
                                + "', overwrite=true)";

                string response = objApiCall.MyHttpWebRequest(url, lstParameters, "", "application/json;odata=verbose", "Post", FileData);

                result.Error = false;
                result.Data = null;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FilePath">Realative server path of file</param>
        /// <returns></returns>
        public static ResponseResult GetFile(string FilePath)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Headers.Add(HttpRequestHeader.Accept, "application/json;odata=verbose");
                    client.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
                    client.Headers.Add("Authorization", "Bearer " + objSharepointResponce.access_token);

                    string url = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite
                                    + "/_api/web/GetFileByServerRelativeUrl('/" + FilePath + "')/$value";

                    Uri endpointUri = new Uri(url);

                    byte[] data = client.DownloadData(endpointUri);

                    result.Error = false;
                    result.Data = data;
                    return result;
                }
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        public static ResponseResult DeleteFile(string ServerRelativeFilePath)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                string response = "";

                APICall objApiCall = new APICall();

                List<APIParameters> lstParameters = new List<APIParameters>();

                string digest = GetFormDigestValue();

                lstParameters.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });
                lstParameters.Add(new APIParameters() { PropertyName = "X-RequestDigest", PropertyValue = digest });
                lstParameters.Add(new APIParameters() { PropertyName = "X-HTTP-Method", PropertyValue = "DELETE" });
                lstParameters.Add(new APIParameters() { PropertyName = "If-Match", PropertyValue = "*" });

                string url = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/GetFileByServerRelativeUrl('" + ServerRelativeFilePath + "')";

                byte[] data = Encoding.ASCII.GetBytes("");

                response = objApiCall.MyHttpWebRequest(url, lstParameters, "application/json", "application/json;odata=verbose", "Post", data);

                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        public static ResponseResult UpdateExistingFile(byte[] FileData, string ServerRelativeFilePath)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                string response = "";

                APICall objApiCall = new APICall();

                List<APIParameters> lstParameters = new List<APIParameters>();

                string digest = GetFormDigestValue();

                lstParameters.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });
                lstParameters.Add(new APIParameters() { PropertyName = "X-RequestDigest", PropertyValue = digest });
                lstParameters.Add(new APIParameters() { PropertyName = "X-HTTP-Method", PropertyValue = "PUT" });

                string url = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/GetFileByServerRelativeUrl('" + ServerRelativeFilePath + "')/$value";

                response = objApiCall.MyHttpWebRequest(url, lstParameters, "application/json", "application/json;odata=verbose", "Post", FileData);

                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        public static ResponseResult SearchFiles(string DocumentLibrary, string FolderPath = "", bool IsServerRelativePath = false)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                APICall objApiCall = new APICall();

                string uri = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/getfolderbyserverrelativeurl('"
                    + ((IsServerRelativePath) ? "" : ("/" + objSharepointResponce.SharePointSite + "/" + DocumentLibrary + "/"))
                     + (string.IsNullOrEmpty(FolderPath) ? "" : (FolderPath + "/")) + "')/Files?$Filter=CustomizedPageStatus eq 0";

                List<APIParameters> lstParameter = new List<APIParameters>();
                lstParameter.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });

                string response = objApiCall.MyHttpWebRequest(uri, lstParameter, "application/json", "application/json;odata=verbose", "Get", null);

                var objResult = JsonConvert.DeserializeObject<SharePointFileResults>(response);

                if (objResult != null)
                {
                    if (objResult.d != null && objResult.d.results != null && objResult.d.results.Count > 0)
                    {
                        result.Data = objResult.d.results.Select(x => new FilesModel { Name = x.Name, ServerRelativeUrl = x.ServerRelativeUrl, DisplayPath = x.ServerRelativeUrl.Replace(("/" + objSharepointResponce.SharePointSite + "/" + DocumentLibrary + "/"), "").Replace(x.Name, "").TrimEnd('/'), TimeCreated = x.TimeCreated, TimeLastModified = x.TimeLastModified }).ToList<FilesModel>();
                    }
                }

                result.Data = (result.Data == null) ? new List<FilesModel>() : result.Data;
                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        public static ResponseResult SearchFolders(string DocumentLibrary, string FolderPath = "", bool IsServerRelativePath = false)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                APICall objApiCall = new APICall();

                string uri = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/getfolderbyserverrelativeurl('"
                     + ((IsServerRelativePath) ? "" : ("/" + objSharepointResponce.SharePointSite + "/" + DocumentLibrary + "/"))
                     + (string.IsNullOrEmpty(FolderPath) ? "" : (FolderPath + "/")) + "')/Folders";

                List<APIParameters> lstParameter = new List<APIParameters>();
                lstParameter.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });

                string response = objApiCall.MyHttpWebRequest(uri, lstParameter, "application/json", "application/json;odata=verbose", "Get", null);

                var objResult = JsonConvert.DeserializeObject<SharePointFolderResults>(response);

                if (objResult != null)
                {
                    if (objResult.d != null && objResult.d.results != null && objResult.d.results.Count > 0)
                    {
                        result.Data = objResult.d.results.Select(x => new FoldersModel { Name = x.Name, ServerRelativeUrl = x.ServerRelativeUrl, TimeCreated = x.TimeCreated, TimeLastModified = x.TimeLastModified }).ToList<FoldersModel>();
                    }
                }

                result.Data = (result.Data == null) ? new List<FoldersModel>() : result.Data;
                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        public static ResponseResult AllFilesInFolder(string DocumentLibrary, string FolderPath)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                lstFiles = new List<FilesModel>();

                SearchFilesFolders(DocumentLibrary, FolderPath);

                result.Data = lstFiles;
                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        private static void SearchFilesFolders(string DocumentLibrary, string FolderPath, bool IsServerRelativePath = false)
        {
            try
            {
                // Get all files within folder
                var fileResult = SearchFiles(DocumentLibrary, FolderPath, IsServerRelativePath);
                if (!fileResult.Error)
                {
                    lstFiles.AddRange(fileResult.Data as List<FilesModel>);
                }

                // Get all folders within folder
                List<FoldersModel> _folders = new List<FoldersModel>();
                var folderResult = SearchFolders(DocumentLibrary, FolderPath, IsServerRelativePath);
                if (!folderResult.Error)
                {
                    _folders = folderResult.Data as List<FoldersModel>;

                    if (_folders.Count > 0)
                    {
                        foreach (FoldersModel item in _folders)
                        {
                            SearchFilesFolders(DocumentLibrary, item.ServerRelativeUrl, true);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion SharePoint File Operations

        #region SharePoint Internal Operations
        // Method which return form digest value
        private static string GetFormDigestValue()
        {
            string newFormDigest = "";
            HttpWebRequest endpointRequest = (HttpWebRequest)HttpWebRequest.Create(objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/contextinfo"); // objSharepointParam.SharePointRESTApi to be used instead of "_api/contextinfo"
            endpointRequest.Method = "POST";
            endpointRequest.ContentLength = 0;
            // endpointRequest.Credentials = credentials;
            endpointRequest.Headers.Add("Authorization", "Bearer " + objSharepointResponce.access_token);
            endpointRequest.Accept = "application/json;odata=verbose";
            endpointRequest.ContentType = "application/json;odata=verbose";

            try
            {
                HttpWebResponse endpointResponse = (HttpWebResponse)endpointRequest.GetResponse();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            try
            {
                WebResponse webResp = endpointRequest.GetResponse();
                Stream webStream = webResp.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string response = responseReader.ReadToEnd();
                var j = JObject.Parse(response);
                var jObj = (JObject)JsonConvert.DeserializeObject(response);
                foreach (var item in jObj["d"].Children())
                {
                    newFormDigest = item.First()["FormDigestValue"].ToString();
                }
                responseReader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return newFormDigest;
        }
        #endregion SharePoint Internal Operations

        #region Get Document Library / List

        public static ResponseResult GetDocumentLibraryAndList()
        {
            ResponseResult result = new ResponseResult();
            try
            {
                APICall objApiCall = new APICall();

                string uri = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/web/Lists?$filter=BaseTemplate eq 101 and Title ne 'Site Assets' and Title ne 'Style Library' and Title ne 'Documents' and Title ne 'Form Templates'";

                List<APIParameters> lstParameter = new List<APIParameters>();
                lstParameter.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });

                string response = objApiCall.MyHttpWebRequest(uri, lstParameter, "application/json", "application/json;odata=verbose", "Get", null);

                var objResult = JsonConvert.DeserializeObject<SharePointFolderResults>(response);

                if (objResult != null)
                {
                    if (objResult.d != null && objResult.d.results != null && objResult.d.results.Count > 0)
                    {
                        result.Data = objResult.d.results.Select(x => new FoldersModel { Title = x.Title }).ToList<FoldersModel>();
                    }
                }

                result.Data = (result.Data == null) ? new List<FoldersModel>() : result.Data;
                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        #endregion

        #region Global Search

        public static ResponseResult GlobalSearch(string Searchtext, string FileExtension)
        {
            ResponseResult result = new ResponseResult();
            try
            {
                APICall objApiCall = new APICall();
                List<GlobalSearchModel> lstResult = new List<GlobalSearchModel>();

                string strbody = "{'request':{'Querytext': '" + Searchtext + "','SelectProperties':{'results':['Title','Author','Path','LastModifiedTime','OriginalPath']}," + (string.IsNullOrWhiteSpace(FileExtension) ? "" : "'RefinementFilters':{'results': ['fileExtension:equals('" + FileExtension + "')']}") + "}}";
                strbody = JsonConvert.SerializeObject(strbody);


                string[] arrPropRes = new string[] { "Title", "Author", "Path", "LastModifiedTime", "OriginalPath" };
                JArray SelectPropArray = new JArray();
                foreach (string str in arrPropRes)
                {
                    SelectPropArray.Add(str);
                }


                JObject SelectPropResult = new JObject();
                SelectPropResult["results"] = SelectPropArray;

                JArray RefinementFilterResult = new JArray();
                if (string.IsNullOrWhiteSpace(FileExtension))
                {
                    RefinementFilterResult.Add("");
                }
                else
                {
                    RefinementFilterResult.Add("fileExtension:equals(" + FileExtension + ")");
                }


                JObject RefinementPropResult = new JObject();
                RefinementPropResult["results"] = RefinementFilterResult;


                JObject OuterReqValue = new JObject();
                OuterReqValue["Querytext"] = Searchtext;
                OuterReqValue["SelectProperties"] = SelectPropResult;
                OuterReqValue["RefinementFilters"] = RefinementPropResult;

                JObject JRequests = new JObject();
                JRequests["request"] = OuterReqValue;

                var json_string = Newtonsoft.Json.JsonConvert.SerializeObject(JRequests);

                string uri = objSharepointResponce.sharepointaaccessurl + objSharepointResponce.SharePointSite + "/_api/search/postquery";

                List<APIParameters> lstParameter = new List<APIParameters>();
                lstParameter.Add(new APIParameters() { PropertyName = "Authorization", PropertyValue = "Bearer " + objSharepointResponce.access_token });

                byte[] data = Encoding.ASCII.GetBytes(json_string);

                string response = objApiCall.MyHttpWebRequest(uri, lstParameter, "application/json;odata=verbose", "application/json", "Post", data);

                JObject myObject = JsonConvert.DeserializeObject<JObject>(response);

                JObject a = (JObject)myObject.SelectToken("PrimaryQueryResult.RelevantResults.Table");

                foreach (JObject item in a["Rows"])
                {
                    GlobalSearchModel objRes = new GlobalSearchModel();

                    foreach (JObject itemCelles in item["Cells"])
                    {

                        if (arrPropRes.Contains(Convert.ToString(itemCelles["Key"])))
                        {
                            objRes.GetType().GetProperty(Convert.ToString(itemCelles["Key"])).SetValue(objRes, Convert.ToString(itemCelles["Value"]), null);
                        }
                    }

                    lstResult.Add(objRes);
                }

                result.Data = lstResult;
                result.Error = false;
                return result;
            }
            catch (Exception ex)
            {
                result.Error = true;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        #endregion
    }
}