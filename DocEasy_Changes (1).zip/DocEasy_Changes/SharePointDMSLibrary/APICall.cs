﻿using SharePointDMSLibrary.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace SharePointDMSLibrary
{
    public class APICall
    {
        public string MyHttpWebRequest(string Url, List<APIParameters> lstHeader, string ContentType, string Accept, string Method, byte[] _ByteArray, bool Useproxy = false)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
                request.Method = Method;
                if (!string.IsNullOrEmpty(Accept) && Accept != "")
                {
                    request.Accept = Accept;
                }
                if (!string.IsNullOrEmpty(ContentType) &&  ContentType != "")
                {
                    request.ContentType = ContentType;
                }

                foreach(APIParameters headerParam in lstHeader){
                    request.Headers.Add(headerParam.PropertyName, headerParam.PropertyValue);
                }

                if(Useproxy)
                {
                    request.Proxy = new WebProxy("zia.edelcap.com", 80);
                }

                if (Method.ToUpper() == "POST" && _ByteArray != null)
                {
                    request.ContentLength = _ByteArray.Length;
                    Stream requestStream = request.GetRequestStream();
                    requestStream.Write(_ByteArray, 0, _ByteArray.Length);
                    requestStream.Close();
                }
                

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                // response.StatusCode
                string responseString = "";

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        responseString = reader.ReadToEnd();
                    }
                }
                
                return responseString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void WebAddHeader(HttpWebRequest client, List<APIParameters> lstHeader)
        {
            if (lstHeader != null && lstHeader.Count > 0)
            {
                foreach (APIParameters par in lstHeader)
                {
                    client.Headers.Add(par.PropertyName, par.PropertyValue);
                }
            }
        }
    }
}