﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace AWS_S3.Services
{
    public class AddRequiredHeaderParameter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {

            #region Add Headers

            if (operation.Parameters == null)
                operation.Parameters = new List<OpenApiParameter>();

            if (operation.OperationId == "token")
            {
                operation.Parameters.Add(new OpenApiParameter() { Name = "clientId", Example = new OpenApiString("ee89f850-c0d5-4ebe-99a2-df6e597983bf"), Description = "Sharepoint Client Id", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "clientSecret", Example = new OpenApiString("fOxhwKn5Y89ftQvJOxWiqHtErToCU6KR/53SwgXCUD0="), Description = "Sharepoint Client Secret", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "tenantId", Example = new OpenApiString("02dbf22a-371e-4cac-bdbc-60197ffafbe8"), Description = "Sharepoint Tenant Id", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "resource", Example = new OpenApiString("00000000-0000-0000-0000-000000000000"), Description = "Sharepoint Resource", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "siteDomain", Example = new OpenApiString("edeltech.sharepoint.com"), Description = "Sharepoint Site Domain", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
            }
            else
            {   
                if (!operation.OperationId.ToUpper().Contains("TAG"))
                    operation.Parameters.Add(new OpenApiParameter() { Name = "target", Example = new OpenApiString("AWS"), Description = "Determine the source of documents.", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false , Enum = GetAppEnum() } });
                if (!operation.OperationId.ToUpper().Contains("TAG"))
                    operation.Parameters.Add(new OpenApiParameter() { Name = "token", Example = new OpenApiString("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkN0VHVoTUptRDVNN0RMZHpEMnYyeDNRS1NSWSIsImtpZCI6IkN0VHVoTUptRDVNN0RMZHpEMnYyeDNRS1NSWSJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTBmZjEtY2UwMC0wMDAwMDAw"), Description = "Sharepoint Token, required when target is SharePoint", AllowEmptyValue = false, In = ParameterLocation.Header, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "accessKey", Example = new OpenApiString("AKIA5VEKB3TMO4T24ZPA"), Description = "Users AWS  Access Key, required when target is AWS", AllowEmptyValue = false, In = ParameterLocation.Header, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "secretKey", Example = new OpenApiString("CwznTz1wQCiJCLle0PH9KOpfUdy5Yf2CFKg3yKHA"), Description = "Users AWS  Secret Key, required when target is AWS", AllowEmptyValue = false, In = ParameterLocation.Header, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                operation.Parameters.Add(new OpenApiParameter() { Name = "targetInfo", Example = new OpenApiString("ap-south-1"), Description = "Mention the AWS S3 Region Name or SharePoint Site Domain Name", AllowEmptyValue = false, In = ParameterLocation.Header, Required = true, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
                if (!operation.OperationId.ToUpper().Contains("TAG"))
                    operation.Parameters.Add(new OpenApiParameter() { Name = "siteName", Example = new OpenApiString("PMTech"), Description = "Specify the SharePoint Name if target is Sharepoint.", AllowEmptyValue = false, In = ParameterLocation.Header, Schema = new OpenApiSchema() { Type = "string", Nullable = false } });
            }

            #endregion

            #region Add Security Schema

            if (operation.Security == null)
                operation.Security = new List<OpenApiSecurityRequirement>();

            var scheme = new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Authorization" } };
            var scheme_xapikey = new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "x-api-key" } };
            operation.Security.Add(new OpenApiSecurityRequirement
            {
                [scheme] = new List<string>()
            });
            operation.Security.Add(new OpenApiSecurityRequirement
            {
                [scheme_xapikey] = new List<string>()
            });

            #endregion

        }

        private IList<IOpenApiAny> GetAppEnum()
        {
            List<IOpenApiAny> lst = new List<IOpenApiAny>();
            lst.Add(OpenApiAnyFactory.CreateFor(new OpenApiSchema() { Type = "string" }, "AWS"));
            lst.Add(OpenApiAnyFactory.CreateFor(new OpenApiSchema() { Type = "string" }, "SharePoint"));

            return lst;
        }
    }
}