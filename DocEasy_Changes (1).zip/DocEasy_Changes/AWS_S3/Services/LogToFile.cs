﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AWS.S3.DataAccess;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;

namespace AWS_S3.Services
{
    public static class LogToFile0
    {
        public static void LogError(Exception ex, string FunctionName, string file_Name = "")
        {

            string wwwPath = Path.Combine(Environment.CurrentDirectory, "Log");

            if (!Directory.Exists(wwwPath))
                Directory.CreateDirectory(wwwPath);

            string dir1 = Path.Combine(wwwPath, "ExceptionLog");

            if (!Directory.Exists(dir1))
                Directory.CreateDirectory(dir1);

            string FinalPath = dir1 + "\\" + (string.IsNullOrEmpty(file_Name) ? Convert.ToString(DateTime.Now.ToString("dd-MM-yyyy")) + ".txt" : file_Name + "_" + Convert.ToString(DateTime.Now.ToString("dd-MM-yyyy")) + ".txt");

            if (!File.Exists(FinalPath))
                File.Create(FinalPath).Dispose();

            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            message += string.Format("Function: {0}", FunctionName);
            message += Environment.NewLine;
            message += string.Format("Message: {0}", ex.Message);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", ex.StackTrace);
            message += Environment.NewLine;
            message += string.Format("Source: {0}", ex.Source);
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;

            using (StreamWriter writer = new StreamWriter(FinalPath, true))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }

        public static bool LogRequest(ApiLogItem obj)
        {
            try
            {
                string wwwPath = Path.Combine(Environment.CurrentDirectory, "Log");

                if (!Directory.Exists(wwwPath))
                    Directory.CreateDirectory(wwwPath);

                string dir1 = Path.Combine(wwwPath, "RequestLog");

                if (!Directory.Exists(dir1))
                    Directory.CreateDirectory(dir1);

                string FinalPath = dir1 + "\\" + Convert.ToString(DateTime.Now.ToString("dd-MM-yyyy")) + ".txt";

                if (!File.Exists(FinalPath))
                    File.Create(FinalPath).Dispose();

                string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;
                message += string.Format("Request: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(obj));
                message += Environment.NewLine;
                message += "-----------------------------------------------------------";
                message += Environment.NewLine;

                using (StreamWriter writer = new StreamWriter(FinalPath, true))
                {
                    writer.WriteLine(message);
                    writer.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
