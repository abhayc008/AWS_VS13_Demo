﻿using DMS_Models.AWSS3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models
{
    public class GetBucketTaggingResponse
    {
        public List<Tag> TagSet { get; set; }
    }
}
