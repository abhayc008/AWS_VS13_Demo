﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.Enum
{
    public enum AppEnum
    {
        AWS = 1,
        SharePoint = 2
    }
}
