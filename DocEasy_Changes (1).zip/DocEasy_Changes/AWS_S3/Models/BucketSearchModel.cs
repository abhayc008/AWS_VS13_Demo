﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models
{
    public class BucketSearchModel
    {
        public BucketSearchModel()
        {
            SearchResult = new List<S3BucketSearchResponse>();
        }
        public string BucketName { get; set; }
        public string FileName { get; set; }

        public bool SearchInAllBucket { get; set; }

        public List<S3BucketSearchResponse> SearchResult { get; set; }
    }


    public class S3BucketSearchResponse
    {
        public string BucketName { get; set; }
        public string FileName { get; set; }

        public bool SearchInAllBucket { get; set; }
    }

    public class S3Bucket
    {
        public string BucketName { get; set; }

        public string FolderPath { get; set; }
    }
}
