﻿using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models
{
    public class SearchModel
    {
        [SwaggerSchema(description:"AWS S3 file eTag, value only when target AWS")]
        public string eTag { get; set; }

        [SwaggerSchema(description: "AWS S3 file's Bucket, value only when target AWS")]
        public string bucketName { get; set; }

        [SwaggerSchema(description: "File path for AWS S3 or SharePoint")]
        public string originalPath { get; set; }
                
        [SwaggerSchema(description: "File Name, value only when target is SharePoint")]
        public string title { get; set; }

        [SwaggerSchema(description: "File Auther Name, value only when target is SharePoint")]
        public string author { get; set; }

        [SwaggerSchema(description: "File last modified, value only when target is SharePoint")]
        public string lastModifiedTime { get; set; }
    }
}
