﻿using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class FailedResponceExample_403 : IExamplesProvider<GenericResponse>
    {
        public GenericResponse GetExamples()
        {
            return new GenericResponse()
            {
                message = "Error Message"
            };
        }
    }
}

