﻿using DMS_Models;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class UploadFileReqExample : IExamplesProvider<UploadFile>
    {
        public UploadFile GetExamples()
        {
            return new UploadFile
            {
                bucketLibrary = "bucket1",
                folderPath="folder1"
            };
        }
    }
}
