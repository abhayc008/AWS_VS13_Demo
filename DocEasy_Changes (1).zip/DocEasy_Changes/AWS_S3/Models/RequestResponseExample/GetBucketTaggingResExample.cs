﻿using DMS_Models;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class GetBucketTaggingResExample : IMultipleExamplesProvider<Amazon.S3.Model.GetBucketTaggingResponse>
    {
        public IEnumerable<SwaggerExample<Amazon.S3.Model.GetBucketTaggingResponse>> GetExamples()
        {
            yield return SwaggerExample.Create<Amazon.S3.Model.GetBucketTaggingResponse>("Success Example",
                new Amazon.S3.Model.GetBucketTaggingResponse()
                {
                    TagSet = new List<Amazon.S3.Model.Tag>()
                        {
                            new Amazon.S3.Model.Tag(){ Key = "bucket1", Value="Pricing"},
                            new Amazon.S3.Model.Tag(){ Key = "Bucket1", Value="Report"}
                        }
                });
        }
    }
}
