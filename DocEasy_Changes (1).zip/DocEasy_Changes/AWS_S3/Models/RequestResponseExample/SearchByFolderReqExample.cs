﻿//using Swashbuckle.AspNetCore.Examples;
using DMS_Models;
using DMS_Models.AWSS3;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class SearchByFolderReqExample : IExamplesProvider<SearchByFolder>
    {
        public SearchByFolder GetExamples()
        {
            return new SearchByFolder
            {
                 bucketLibrary ="TestLib",
                folderPath = "/sites/PMTech/TestLib"
            };
        }
    }
}
