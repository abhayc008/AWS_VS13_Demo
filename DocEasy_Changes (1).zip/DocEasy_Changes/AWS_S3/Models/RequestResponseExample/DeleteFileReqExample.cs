﻿using DMS_Models;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class DeleteFileReqExample : IExamplesProvider<DeleteFile>
    {
        public DeleteFile GetExamples()
        {
            return new DeleteFile
            {
                bucketName = "",
                filePath = ""
            };
        }
    }
}
