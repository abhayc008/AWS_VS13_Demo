﻿//using Swashbuckle.AspNetCore.Examples;
using DMS_Models.AWSS3;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class AddTagReqExample : IExamplesProvider<AddTag>
    {
        public AddTag GetExamples()
        {
            return new AddTag
            {
                BucketName = "testbucket",
                Tags = new List<Tag>()
                {
                    new Tag
                    {
                        key="KeyPrice",
                        Value   ="Price"
                    },
                    new Tag
                    {
                        key="KeyReport",
                        Value   ="Report"
                    }
                }
            };
        }
    }
}
