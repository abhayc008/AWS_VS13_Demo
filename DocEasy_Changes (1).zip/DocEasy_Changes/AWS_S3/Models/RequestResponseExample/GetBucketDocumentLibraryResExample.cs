﻿using DMS_Models;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class GetBucketDocumentLibraryResExample : IExamplesProvider<DocumentLibrary>
    {
        public DocumentLibrary GetExamples()
        {
            return new DocumentLibrary()
            {

                creationDate = "2020-02-17T18:45:30+5:30",
                bucketLibrary = "bucket1"

            };
        }
    }
}
