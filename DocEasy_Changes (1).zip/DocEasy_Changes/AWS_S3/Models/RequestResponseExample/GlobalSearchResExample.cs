﻿using Amazon.S3.Model;
using DMS_Models;
using DMS_Models.SharePoint;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class GlobalSearchResExample : IExamplesProvider<SearchModel>
    {
        public SearchModel GetExamples()
        {
            return new SearchModel()
            {
                eTag = "",
                bucketName = "",
                originalPath = "https://edeltech.sharepoint.com/sites/PMTech/TestLib/Test.pdf",
                author = "Kunal",
                lastModifiedTime = "2020-02-17T18:45:30+5:30",
                title = "Test"
            };
        }
    }
}
