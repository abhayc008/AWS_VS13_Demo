﻿using DMS_Models;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class AccessTokenResExample : IExamplesProvider<SuccessToken>
    {
        public SuccessToken GetExamples()
        {
            return new SuccessToken()
            {
                 accessToken = "TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1dCBieSB0aGlzIHNpbmd1bGFyIHBhc3Npb24gZnJvbSBvdGhlciBhbmltYWxzLCB3aGljaCBpcyBhIGx1c3Qgb2YgdGhlIG1pbmQsIHRoYXQgYnkgYSBwZXJzZXZlcmFuY2Ug" 
            };

        }

        //public IEnumerable<SwaggerExample<ResponseResult>> GetExamples()
        //{
        //    yield return SwaggerExample.Create<ResponseResult>("Success Example",
        //        new ResponseResult()
        //        {
        //            Error = false,
        //            ErrorMessage = string.Empty,
        //            Data = new { access_token = "TWFuIGlzIGRpc3Rpbmd1aXNoZWQsIG5vdCBvbmx5IGJ5IGhpcyByZWFzb24sIGJ1dCBieSB0aGlzIHNpbmd1bGFyIHBhc3Npb24gZnJvbSBvdGhlciBhbmltYWxzLCB3aGljaCBpcyBhIGx1c3Qgb2YgdGhlIG1pbmQsIHRoYXQgYnkgYSBwZXJzZXZlcmFuY2Ug" }
        //        });

        //    yield return SwaggerExample.Create<ResponseResult>("Failed Example",
        //       new ResponseResult()
        //       {
        //           Error = true,
        //           ErrorMessage = "Internal server error",
        //           Data = { }
        //       });
        //}
    }
}
