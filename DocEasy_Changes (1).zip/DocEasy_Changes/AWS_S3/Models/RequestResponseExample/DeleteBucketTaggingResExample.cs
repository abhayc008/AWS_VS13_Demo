﻿using DMS_Models;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.RequestResponseExample
{
    public class DeleteBucketTaggingResExample : IExamplesProvider<GenericResponse>
    {
        public GenericResponse GetExamples()
        {
            return new GenericResponse() { message = "Bucket Tag(s) deleted successfully." };
        }
    }
}
