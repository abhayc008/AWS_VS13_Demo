﻿using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models
{
    public class SuccessToken
    {
        [SwaggerSchema(description:"A valid JWT token for sharepoint site, expires in 3600 secs.")]
        public string accessToken { get; set; }
    }
}
