﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models.Account
{
    public class RegisterViewModel
    {
        [Required]
        public string ApplicationName { get; set; }
                

        [Required]
        [DataType(DataType.Password)]
        [MinLength(8)]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name ="Confirm Password")]
        [Compare("Password",ErrorMessage = "Password and Confirm Password do not match.")]
        public string ConfirmPassword { get; set; }
        
        [Required]
        public string AWS_AccessKey { get; set; }
        
        [Required]
        public string AWS_SecretKey { get; set; }

        [Required]
        public string AWS_Bucket { get; set; }

        public string AWS_BucketFolder { get; set; }

    }
}
