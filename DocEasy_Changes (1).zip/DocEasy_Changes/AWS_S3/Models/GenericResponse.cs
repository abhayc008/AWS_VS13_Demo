﻿using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Models
{
    public class GenericResponse
    {
        [SwaggerSchema(description:"Message description")]
        public string message { get; set; }
    }
}
