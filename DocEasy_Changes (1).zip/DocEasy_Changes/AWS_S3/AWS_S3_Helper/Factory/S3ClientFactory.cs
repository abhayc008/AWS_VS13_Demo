﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace AWS_S3.AWS_S3_Helper.Factory
{
    public static class S3ClientFactory
    {

        public static AmazonS3Client GetS3Client(string systemName)
        {
            var regionEndPoint = RegionEndpoint.GetBySystemName(systemName);

            var config = new AmazonS3Config
            {   
                RegionEndpoint = regionEndPoint
            };
            config.SetWebProxy(new WebProxy("http://zia.edelcap.com:80"));
            return new AmazonS3Client(new BasicAWSCredentials(AwsConstant.AccessKey, AwsConstant.SecretKey), config);
        }
    }
}
