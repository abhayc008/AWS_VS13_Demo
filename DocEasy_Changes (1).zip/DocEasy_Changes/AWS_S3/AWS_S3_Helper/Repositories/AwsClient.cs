﻿using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AWS_S3.AWS_S3_Helper.Factory;
using System.IO;

namespace AWS_S3.AWS_S3_Helper.Repositories
{
    public sealed class AwsClient : IAwsClient
    {
        private IAmazonS3 client;

        public AwsClient()
        {
            client = S3ClientFactory.GetS3Client(AwsConstant.DefaultS3Region);
        }

        public async Task<PutBucketResponse> CreateBucketAsync(string bucketName)
        {
            var resp = await client.PutBucketAsync(new PutBucketRequest()
            {
                BucketName = bucketName,
                BucketRegion = AwsConstant.s3Region
            }).ConfigureAwait(false);
            return resp;
        }

        public async Task<DeleteBucketResponse> DeleteBucketAsync(string bucketName)
        {
            return await client.DeleteBucketAsync(bucketName).ConfigureAwait(false);
        }


        public async Task<IEnumerable<S3Bucket>> GetBucketsAsync()
        {
            var resp = await client.ListBucketsAsync().ConfigureAwait(false);
            var res = Task.FromResult<IEnumerable<S3Bucket>>(resp.Buckets).ConfigureAwait(false);
            return await res;
        }

        public async Task<PutObjectResponse> UploadFile(string bucketName, Stream inputStream, string folderName, string fileNameWithExtension)
        {

            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value);

            var req = new PutObjectRequest()
            {
                BucketName = bucketName + (string.IsNullOrEmpty(folderName) ? "" : "/" + folderName),
                InputStream = inputStream,
                Key = fileNameWithExtension,

            };
            var res = client2.PutObjectAsync(req).ConfigureAwait(false);
            client2 = null;
            return await res;
        }

        public async Task<GetObjectResponse> DownloadFile(string fileName, string bucketName)
        {
            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value);

            var req = new GetObjectRequest()
            {
                BucketName = bucketName,
                Key = fileName
            };

            //var allFiles = await client.ListObjectsAsync(bucketName).ConfigureAwait(false);
            var res = client2.GetObjectAsync(req).ConfigureAwait(false);

            return await res;
        }

        public async Task<IEnumerable<S3Object>> GlobalSearchAsync(string docToSearch)
        {
            var allBuckets = await GetBucketsAsync().ConfigureAwait(false);
            var data = new List<S3Object>();
            foreach (var item in allBuckets)
            {
                data.AddRange(await GetAllObjectsAsync(item.BucketName).ConfigureAwait(false));
            }

            return await Task.FromResult<IEnumerable<S3Object>>(data.Where(x => x.Key.ToUpperInvariant().Contains(docToSearch.ToUpperInvariant()))).ConfigureAwait(false);
        }

        public async Task<IEnumerable<S3Object>> GetAllObjectsAsync(string bucketName)
        {
            var buketRegion = await client.GetBucketLocationAsync(bucketName, new CancellationToken()).ConfigureAwait(false);
            var client2 = S3ClientFactory.GetS3Client(buketRegion.Location.Value);
            var resp = await client2.ListObjectsV2Async(new ListObjectsV2Request() { BucketName = bucketName }, new CancellationToken()).ConfigureAwait(false);
            var res = Task.FromResult<IEnumerable<S3Object>>(resp.S3Objects).ConfigureAwait(false);
            client2 = null;
            return await res;
        }
    }
}
