﻿using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.AWS_S3_Helper.Repositories
{
    public interface IAwsClient
    {
        Task<IEnumerable<S3Bucket>> GetBucketsAsync();
        Task<PutBucketResponse> CreateBucketAsync(string bucketName);
        Task<DeleteBucketResponse> DeleteBucketAsync(string bucketName);
        Task<PutObjectResponse> UploadFile(string bucketName, Stream inputStream, string folderName, string fileNameWithExtension);
        Task<GetObjectResponse> DownloadFile(string fileName, string bucketName);
        Task<IEnumerable<S3Object>> GlobalSearchAsync(string docToSearch);
        Task<IEnumerable<S3Object>> GetAllObjectsAsync(string bucketName);


    }
}
