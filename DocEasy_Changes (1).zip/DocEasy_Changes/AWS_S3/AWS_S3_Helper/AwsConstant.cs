﻿using Amazon;
using Amazon.S3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.AWS_S3_Helper
{
    public static class AwsConstant
    {
        public static readonly string AccessKey = "AKIA5VEKB3TMO4T24ZPO";
        public static readonly string SecretKey = "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";
        public static readonly RegionEndpoint regionEndpoint = RegionEndpoint.APSouth1;
        public static readonly S3Region s3Region = S3Region.APS3;
        public static readonly string DefaultS3Region = "ap-south-1";
    }
}
