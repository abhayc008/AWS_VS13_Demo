﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AWS.S3.DataAccess;
using AWS_S3.Models.Account;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using DMS_Models;
using SharePointDMSLibrary_API;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;
using AWS_S3.Models.RequestResponseExample;
using Microsoft.AspNetCore.Http;

namespace SharepointDMS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [ApiExplorerSettings(GroupName = "v1")]
    [SwaggerTag(description: "This authentication is used for Sharepoint site access.")]
    public class authenticationController : ControllerBase
    {
        [HttpPost("getToken")]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(GetAccessTokenResExample))]
        [ProducesResponseType(typeof(ResponseResult), 200)]           
        //[Produces("application/json")]
        public IActionResult getToken()
        {
            ResponseResult objResult = new ResponseResult();
            try
            {
                string appID = string.Empty;
                string clientId = string.Empty;
                string clientSecret = string.Empty;
                string tenantId = string.Empty;
                string resource = string.Empty;
                string siteDomain = string.Empty;

                if (Request.Headers["appID"].Any())
                    appID = Request.Headers["appID"];

                if (Request.Headers["clientId"].Any())
                    clientId = Request.Headers["clientId"];

                if (Request.Headers["clientSecret"].Any())
                    clientSecret = Request.Headers["clientSecret"];

                if (Request.Headers["tenantId"].Any())
                    tenantId = Request.Headers["tenantId"];

                if (Request.Headers["resource"].Any())
                    resource = Request.Headers["resource"];

                if (Request.Headers["siteDomain"].Any())
                    siteDomain = Request.Headers["siteDomain"];

                objResult = SharepointServices_API.GetAccessToken(clientId, clientSecret, tenantId, resource, siteDomain);

                return Ok(objResult);
            }
            catch (Exception ex)
            {
                objResult.Error = true;
                objResult.ErrorMessage = ex.Message;
                return Ok(objResult);
            }
        }
    }
}