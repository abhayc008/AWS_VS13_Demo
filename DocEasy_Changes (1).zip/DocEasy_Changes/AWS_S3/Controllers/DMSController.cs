﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AWS_S3.Models;
using AWS_S3.Models.RequestResponseExample;
using AWSS3DMSLibrary.Repositories;
using DMS_Models;
using DMS_Models.AWSS3;
using DMS_Models.SharePoint;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SharePointDMSLibrary_API;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;

namespace AWS_S3.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    //[SwaggerTag(description: "Generate token for sharepoint operations. Operations pertaning to Document Management System like file create, read, update ,delete, tag ,search etc.")]
    public class dmsController : ControllerBase
    {
        [HttpPost("token")]
        [SwaggerOperation(summary: "API for generating token for accessing SharePoint", Tags = new[] { "Authentication" })]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(AccessTokenResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(SuccessToken), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        public IActionResult token()
        {
            try
            {
                ResponseResult objResult = new ResponseResult();
                SuccessToken obj = new SuccessToken();

                string target = string.Empty;
                string clientId = string.Empty;
                string clientSecret = string.Empty;
                string tenantId = string.Empty;
                string resource = string.Empty;
                string siteDomain = string.Empty;

                if (Request.Headers["clientId"].Any())
                    clientId = Request.Headers["clientId"];

                if (Request.Headers["clientSecret"].Any())
                    clientSecret = Request.Headers["clientSecret"];

                if (Request.Headers["tenantId"].Any())
                    tenantId = Request.Headers["tenantId"];

                if (Request.Headers["resource"].Any())
                    resource = Request.Headers["resource"];

                if (Request.Headers["siteDomain"].Any())
                    siteDomain = Request.Headers["siteDomain"];

                objResult = SharepointServices_API.GetAccessToken(clientId, clientSecret, tenantId, resource, siteDomain);

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                obj.accessToken = objResult.Data as string;
                return Ok(obj);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



        [HttpGet("bucketLibrary")]
        [SwaggerOperation(summary: "Retrive Bucket / Document Library details.", description: "", Tags = new[] { "Data Management" })]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(GetBucketDocumentLibraryResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(DocumentLibrary), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        public IActionResult bucketLibrary()
        {
            try
            {
                ResponseResult objResult = new ResponseResult();
                List<DocumentLibrary> lstResultData = new List<DocumentLibrary>();

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["target"].Any())
                    target = Request.Headers["target"];

                if (Request.Headers["token"].Any())
                    token = Request.Headers["token"];

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                if (Request.Headers["siteName"].Any())
                    siteName = Request.Headers["siteName"];

                if (target.ToUpper() == "AWS") // AWS S3
                {
                    AwsClient client = new AwsClient();
                    Task<IEnumerable<Amazon.S3.Model.S3Bucket>> res = client.GetBucketsAsync(targetInfo, accessKey, secretKey);

                    if (res != null && res.Result != null)
                        foreach (var item in res.Result)
                        {
                            lstResultData.Add(new DocumentLibrary() { bucketLibrary = item.BucketName, creationDate = Convert.ToString(item.CreationDate) });
                        }

                    objResult.Data = lstResultData;
                }
                else if (target.ToUpper() == "SHAREPOINT") //Sharepoint
                {
                    objResult = SharepointServices_API.GetDocumentLibraryAndList(token, targetInfo, siteName);

                    if (objResult != null && objResult.Data != null)
                        foreach (var item in objResult.Data as List<FoldersModel>)
                        {
                            lstResultData.Add(new DocumentLibrary() { bucketLibrary = item.Title });
                        }

                    objResult.Data = lstResultData;
                }
                else if (target.ToUpper() == "ONEDRIVE") // One Drive
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "One Drive services is not configured.";
                }
                else
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Invalid App Id.";
                }

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

        }



        [HttpPost("upload")]
        [SwaggerOperation(summary: "Upload document in S3 or SharePoint", description: "", Tags = new[] { "Data Management" })]
        [SwaggerRequestExample(typeof(UploadFile), typeof(UploadFileReqExample))]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(UploadFileResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        [RequestFormLimits(MultipartBodyLengthLimit = 154857600)] // 154 MB
        [RequestSizeLimit(154857600)] //154 MB
        public IActionResult upload([FromForm]UploadFile objUploadFile)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();

                if (string.IsNullOrEmpty(objUploadFile.bucketLibrary))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide Bucket_Library";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }


                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["target"].Any())
                    target = Request.Headers["target"];

                if (Request.Headers["token"].Any())
                    token = Request.Headers["token"];

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                if (Request.Headers["siteName"].Any())
                    siteName = Request.Headers["siteName"];


                if (objUploadFile.file == null || objUploadFile.file.Length <= 0)
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Plesae add file to upload!";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                string FileName = objUploadFile.file.FileName;

                if (target.ToUpper() == "AWS") // AWS S3
                {
                    AwsClient client = new AwsClient();

                    System.IO.Stream dataStream = objUploadFile.file.OpenReadStream();
                    Task<Amazon.S3.Model.PutObjectResponse> res = client.UploadFile(objUploadFile.bucketLibrary, dataStream, objUploadFile.folderPath, FileName, targetInfo, accessKey, secretKey);

                    var result = res.Result;

                    objResult.Data = "File uploaded successfully.";
                }
                else if (target.ToUpper() == "SHAREPOINT") //Sharepoint
                {
                    System.IO.Stream dataStream = objUploadFile.file.OpenReadStream();
                    byte[] fileData;
                    using (var memoryStream = new System.IO.MemoryStream())
                    {
                        dataStream.CopyTo(memoryStream);
                        fileData = memoryStream.ToArray();

                        objResult = SharepointServices_API.UploadFile(token, targetInfo, siteName, objUploadFile.bucketLibrary, fileData, FileName, objUploadFile.folderPath);
                    }
                }
                else if (target.ToUpper() == "ONEDRIVE") // One Drive
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "One Drive services is not configured.";
                }
                else
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Invalid Target.";
                }

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



        [HttpPost("download")]
        [SwaggerOperation(summary: "Download document from S3 or SharePoint", description: "", Tags = new[] { "Data Management" })]
        [SwaggerRequestExample(typeof(DownloadFile), typeof(DownloadFileReqExample))]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(DownloadFileResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [RequestFormLimits(MultipartBodyLengthLimit = 154857600)] // 154 MB
        [RequestSizeLimit(154857600)] //154 MB
        //[Consumes("application/x-www-form-urlencoded")]
        public IActionResult download([FromBody]DownloadFile objDownloadFile)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["target"].Any())
                    target = Request.Headers["target"];

                if (Request.Headers["token"].Any())
                    token = Request.Headers["token"];

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                if (Request.Headers["siteName"].Any())
                    siteName = Request.Headers["siteName"];

                if (string.IsNullOrEmpty(objDownloadFile.filePath))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide FilePath";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                if (target.ToUpper() == "AWS" && string.IsNullOrEmpty(objDownloadFile.bucketName))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide BucketName";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }


                if (target.ToUpper() == "AWS") // AWS S3
                {
                    AwsClient client = new AwsClient();
                    Task<Amazon.S3.Model.GetObjectResponse> res = client.DownloadFile(objDownloadFile.filePath, objDownloadFile.bucketName, targetInfo, accessKey, secretKey);

                    return File(res.Result.ResponseStream, res.Result.Headers["Content-Type"], objDownloadFile.filePath);
                }
                else if (target.ToUpper() == "SHAREPOINT") //Sharepoint
                {
                    objResult = SharepointServices_API.GetFile(token, targetInfo, siteName, objDownloadFile.filePath);

                    if (!objResult.Error)
                    {
                        byte[] data = objResult.Data as byte[];
                        return File(data, "application/octet-stream", objDownloadFile.filePath);
                    }
                }
                else if (target.ToUpper() == "ONEDRIVE") // One Drive
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "One Drive services is not configured.";
                }
                else
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Invalid Target.";
                }

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        [HttpPost("deleteFile")]
        [SwaggerOperation(summary: "API for deleting file from AWS or SharePoint", Tags = new[] { "Data Management" })]
        [SwaggerRequestExample(typeof(DeleteFile), typeof(DeleteFileReqExample))]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(DeleteFileResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        public IActionResult deleteFile([FromBody]DeleteFile objDeleteFile)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["target"].Any())
                    target = Request.Headers["target"];

                if (Request.Headers["token"].Any())
                    token = Request.Headers["token"];

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                if (Request.Headers["siteName"].Any())
                    siteName = Request.Headers["siteName"];

                if (string.IsNullOrEmpty(objDeleteFile.filePath))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide FilePath";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                if (target.ToUpper() == "AWS" && string.IsNullOrEmpty(objDeleteFile.bucketName))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide BucketName";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }


                if (target.ToUpper() == "AWS") // AWS S3
                {
                    AwsClient client = new AwsClient();
                    Task<Amazon.S3.Model.DeleteObjectResponse> res = client.DeleteFile(objDeleteFile.filePath, objDeleteFile.bucketName, targetInfo, accessKey, secretKey);

                    var result = res.Result;

                    objResult.Error = false;
                    objResult.Data = "File Deleted successfully.";
                }
                else if (target.ToUpper() == "SHAREPOINT") //Sharepoint
                {
                    objResult = SharepointServices_API.DeleteFile(token, targetInfo, siteName, objDeleteFile.filePath);

                }
                else if (target.ToUpper() == "ONEDRIVE") // One Drive
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "One Drive services is not configured.";
                }
                else
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Invalid Target.";
                }

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("search")]
        [SwaggerOperation(summary: "Search document in S3 or SharePoint", description: "", Tags = new[] { "Data Management" })]
        [SwaggerRequestExample(typeof(GlobalSearch), typeof(GlobalSearchReqExample))]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(GlobalSearchResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(SearchModel), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        public IActionResult search([FromQuery]GlobalSearch objGlobalSearch)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();
                List<SearchModel> lstResult = new List<SearchModel>();

                if (string.IsNullOrEmpty(objGlobalSearch.fileName))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide FileName";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["target"].Any())
                    target = Request.Headers["target"];

                if (Request.Headers["token"].Any())
                    token = Request.Headers["token"];

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                if (Request.Headers["siteName"].Any())
                    siteName = Request.Headers["siteName"];


                if (target.ToUpper() == "AWS") // AWS S3
                {
                    AwsClient client = new AwsClient();
                    Task<IEnumerable<Amazon.S3.Model.S3Object>> res = client.GlobalSearchAsync(objGlobalSearch.fileName, targetInfo, accessKey, secretKey);

                    var result = res.Result;

                    if (res != null && res.Result != null)
                        foreach (var item in res.Result)
                        {
                            lstResult.Add(new SearchModel() { eTag = item.ETag, bucketName = item.BucketName, originalPath = item.Key });
                        }

                    objResult.Data = lstResult;
                }
                else if (target.ToUpper() == "SHAREPOINT") //Sharepoint
                {
                    objResult = SharepointServices_API.GlobalSearch(token, targetInfo, siteName, objGlobalSearch.fileName, objGlobalSearch.fileExtension);

                    if (objResult.Data != null)
                        foreach (var item in objResult.Data as List<GlobalSearchModel>)
                        {
                            lstResult.Add(new SearchModel() { title = item.Title, author = item.Author, lastModifiedTime = item.LastModifiedTime, originalPath = item.OriginalPath });
                        }

                    objResult.Data = lstResult;
                }
                else if (target.ToUpper() == "ONEDRIVE") // One Drive
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "One Drive services is not configured.";
                }
                else
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Invalid Target.";
                }

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        [HttpPost("searchByFolder")]
        [SwaggerOperation(summary: "Search document in S3 or SharePoint by folder", description: "", Tags = new[] { "Data Management" })]
        [SwaggerRequestExample(typeof(SearchByFolder), typeof(GlobalSearchReqExample))]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(GlobalSearchResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(SearchModel), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        public IActionResult searchByFolder([FromBody]SearchByFolder objSearchByFolder)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();
                List<SearchModel> lstResult = new List<SearchModel>();

                if (string.IsNullOrEmpty(objSearchByFolder.bucketLibrary))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide bucketLibrary";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                if (string.IsNullOrEmpty(objSearchByFolder.folderPath))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide Folderpath";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["target"].Any())
                    target = Request.Headers["target"];

                if (Request.Headers["token"].Any())
                    token = Request.Headers["token"];

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                if (Request.Headers["siteName"].Any())
                    siteName = Request.Headers["siteName"];


                if (target.ToUpper() == "AWS") // AWS S3
                {
                    AwsClient client = new AwsClient();
                    Task<IEnumerable<Amazon.S3.Model.S3Object>> res = client.GetAllObjectsByFolderAsync(objSearchByFolder.bucketLibrary, targetInfo, accessKey, secretKey, objSearchByFolder.bucketLibrary);

                    var result = res.Result;

                    if (res != null && res.Result != null)
                        foreach (var item in res.Result)
                        {
                            lstResult.Add(new SearchModel() { eTag = item.ETag, bucketName = item.BucketName, originalPath = item.Key });
                        }

                    objResult.Data = lstResult;
                }
                else if (target.ToUpper() == "SHAREPOINT") //Sharepoint
                {
                    objResult = SharepointServices_API.SearchFiles(token, targetInfo, siteName, objSearchByFolder.bucketLibrary, objSearchByFolder.folderPath);

                    if (objResult.Data != null)
                        foreach (var item in objResult.Data as List<FilesModel>)
                        {
                            lstResult.Add(new SearchModel() { title = item.Name, author = string.Empty, lastModifiedTime = Convert.ToString(item.TimeLastModified), originalPath = item.ServerRelativeUrl });
                        }

                    objResult.Data = lstResult;
                }
                else if (target.ToUpper() == "ONEDRIVE") // One Drive
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "One Drive services is not configured.";
                }
                else
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Invalid Target.";
                }

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }


        [HttpPost("tag")]
        [SwaggerOperation(summary: "Add Tags to S3 bucket", description: "", OperationId = "addTag", Tags = new[] { "Tag" })]
        [SwaggerRequestExample(typeof(AddTag), typeof(AddTagReqExample))]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(AddTagResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        //[Consumes("application/x-www-form-urlencoded")]
        [Produces("application/json")]
        public IActionResult tag([FromBody]AddTag objAddTag)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();

                if (string.IsNullOrEmpty(objAddTag.BucketName))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide bucket name";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }
                if (objAddTag.Tags.Count == 0)
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Add atleast on tag!";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;


                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];


                AwsClient client = new AwsClient();

                List<Amazon.S3.Model.Tag> Tags = new List<Amazon.S3.Model.Tag>();
                foreach (var item in objAddTag.Tags)
                {
                    Tags.Add(new Amazon.S3.Model.Tag() { Key = item.key, Value = item.Value });
                }

                Task<Amazon.S3.Model.PutBucketTaggingResponse> res = client.PutBucketTaggingAsync(objAddTag.BucketName, Tags, targetInfo, accessKey, secretKey);

                var result = res.Result;

                objResult.Data = "Bucket Tag(s) added successfully.";

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



        [HttpGet("tag")]
        [SwaggerOperation(summary: "Retrive Tags of S3 bucket", description: "", OperationId = "getTag", Tags = new[] { "Tag" })]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(GetBucketTaggingResExample))]
        [ProducesResponseType(typeof(GetBucketTaggingResponse), 200)]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        [Produces("application/json")]
        public IActionResult tag([FromQuery, SwaggerParameter("Bucket Name", Required = true)]string bucketName)
        {
            try
            {
                ResponseResult objResult = new ResponseResult();
                List<Amazon.S3.Model.Tag> lstResult = new List<Amazon.S3.Model.Tag>();

                if (string.IsNullOrEmpty(bucketName))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide bucket name";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;


                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];

                AwsClient client = new AwsClient();
                Task<Amazon.S3.Model.GetBucketTaggingResponse> res = client.GetBucketTaggingAsync(bucketName, targetInfo, accessKey, secretKey);

                var result = res.Result;

                if (res != null && res.Result != null && res.Result.TagSet != null)
                    lstResult = res.Result.TagSet;

                objResult.Data = lstResult;

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



        [HttpDelete("tag")]
        [SwaggerOperation(summary: "Remove Tags from S3 bucket", description: "", OperationId = "deleteTag", Tags = new[] { "Tag" })]
        [SwaggerResponseExample(StatusCodes.Status200OK, typeof(DeleteBucketTaggingResExample))]
        [SwaggerResponseExample(StatusCodes.Status500InternalServerError, typeof(FailedResponceExample))]
        [SwaggerResponseExample(StatusCodes.Status400BadRequest, typeof(FailedResponceExample_400))]
        [SwaggerResponseExample(StatusCodes.Status401Unauthorized, typeof(FailedResponceExample_401))]
        [SwaggerResponseExample(StatusCodes.Status403Forbidden, typeof(FailedResponceExample_403))]
        [ProducesResponseType(typeof(GenericResponse), 200)]
        [ProducesResponseType(typeof(GenericResponse), 400)]
        [ProducesResponseType(typeof(GenericResponse), 401)]
        [ProducesResponseType(typeof(GenericResponse), 403)]
        [ProducesResponseType(typeof(GenericResponse), 500)]
        //[Consumes("application/x-www-form-urlencoded")]
        [Produces("application/json")]
        public IActionResult deleteTag([FromQuery, SwaggerParameter("Bucket Name", Required = true)]string bucketName)
        {
            ResponseResult objResult = new ResponseResult();
            try
            {
                if (string.IsNullOrEmpty(bucketName))
                {
                    objResult.Error = true;
                    objResult.ErrorMessage = "Please provide bucket name";
                    return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                string target = string.Empty;
                string token = string.Empty;
                string accessKey = string.Empty;
                string secretKey = string.Empty;
                string targetInfo = string.Empty;
                string siteName = string.Empty;

                if (Request.Headers["accessKey"].Any())
                    accessKey = Request.Headers["accessKey"];

                if (Request.Headers["secretKey"].Any())
                    secretKey = Request.Headers["secretKey"];

                if (Request.Headers["targetInfo"].Any())
                    targetInfo = Request.Headers["targetInfo"];


                AwsClient client = new AwsClient();
                Task<Amazon.S3.Model.DeleteBucketTaggingResponse> res = client.DeleteBucketTaggingAsync(bucketName, targetInfo, accessKey, secretKey);

                var result = res.Result;

                objResult.Data = "Bucket Tag(s) deleted successfully.";

                if (objResult.Error)
                {
                    if (objResult.ErrorMessage.Contains("(400)"))
                        return StatusCode(StatusCodes.Status400BadRequest, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(401)"))
                        return StatusCode(StatusCodes.Status401Unauthorized, objResult.ErrorMessage);
                    else if (objResult.ErrorMessage.Contains("(403)"))
                        return StatusCode(StatusCodes.Status403Forbidden, objResult.ErrorMessage);
                    else
                        return StatusCode(StatusCodes.Status500InternalServerError, objResult.ErrorMessage);
                }

                return Ok(objResult.Data);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

    }

}
