﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AWS.S3.DataAccess;
using AWS_S3.Models.Account;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AWS_S3.Controllers
{
    //[ApiController]
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;

        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
        }
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await userManager.CreateAsync(new ApplicationUser()
                {
                    UserName = model.ApplicationName,
                    AWS_AccessKey = model.AWS_AccessKey,
                    AWS_SecretKey = model.AWS_SecretKey,
                    AWS_Bucket = model.AWS_Bucket,
                    AWS_BucketFolder = model.AWS_BucketFolder
                }, model.Password);

                if(result.Succeeded)
                {
                    return RedirectToAction();
                }

                foreach(var error in  result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View(model);
        }


    }
}