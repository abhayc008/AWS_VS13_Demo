﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using AWS_S3.AWS_S3_Helper.Repositories;
using AWS_S3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;

namespace AWS_S3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IAwsClient client;

        public HomeController(ILogger<HomeController> logger, IAwsClient client)
        {
            _logger = logger;
            this.client = client;
        }

        public async Task<IActionResult> Index(BucketSearchModel model)
        {
            if (model.BucketName == null || model.BucketName == "")
            {
                model.SearchInAllBucket = true;
            }
            if (model.FileName == null)
                model.FileName = "";


            if (model.SearchInAllBucket)
            {
                model.SearchResult = (await client.GlobalSearchAsync(model.FileName)).Select(x => new S3BucketSearchResponse()
                {
                    BucketName = x.BucketName,
                    FileName = x.Key,
                    SearchInAllBucket = true
                }).ToList();
            }
            else
            {
                model.SearchResult = (await client.GetAllObjectsAsync(model.BucketName)).Select(x => new S3BucketSearchResponse()
                {
                    BucketName = x.BucketName,
                    FileName = x.Key,
                    SearchInAllBucket = false
                }).ToList();
            }

            var allBukcets = await client.GetBucketsAsync();
            ViewBag.Buckets = allBukcets.Select(x => new SelectListItem()
            {
                Text = x.BucketName,
                Value = x.BucketName
            });

            return
                View("Index", model);
        }

        [HttpGet]
        public async Task<IActionResult> CreateBucket()
        {
            S3Bucket s3Bucket = new S3Bucket();
            return View(s3Bucket);
        }

        [HttpPost]
        public async Task<IActionResult> CreateBucket(S3Bucket s3Bucket)
        {
            try
            {
                await client.CreateBucketAsync(s3Bucket.BucketName);
                s3Bucket.BucketName = "";
                ViewBag.SuccessMessage = "Bucket created successfully.";
            }
            catch (Exception ex)
            {
                s3Bucket.BucketName = "";
                ViewBag.ErrorMessage = ex.Message;
            }
            return View(s3Bucket);
        }

        public async Task<IActionResult> UploadDocument()
        {
            S3Bucket s3Bucket = new S3Bucket();

            var allBukcets = await client.GetBucketsAsync();
            ViewBag.Buckets = allBukcets.Select(x => new SelectListItem()
            {
                Text = x.BucketName,
                Value = x.BucketName
            });

            return View(s3Bucket);
        }

        [HttpPost]
        public async Task<IActionResult> UploadDocument(S3Bucket s3Bucket)
        {

            var allBukcets = await client.GetBucketsAsync();
            ViewBag.Buckets = allBukcets.Select(x => new SelectListItem()
            {
                Text = x.BucketName,
                Value = x.BucketName
            });

            if (s3Bucket.BucketName == null || s3Bucket.BucketName == "")
            {
                ViewBag.ErrorMessage = "Please select bucket";
                return View(s3Bucket);
            }
            else if (Request.Form.Files.Count == 0)
            {
                ViewBag.ErrorMessage = "Please browse file";
                return View(s3Bucket);
            }

            try
            {
                await client.UploadFile(s3Bucket.BucketName, Request.Form.Files[0].OpenReadStream(), s3Bucket.FolderPath ?? "", Request.Form.Files[0].FileName);
                ViewBag.SuccessMessage = "File uploaded succesfully";
                return View(s3Bucket);
            }
            catch (Exception ex)
            {
                s3Bucket.BucketName = "";
                ViewBag.ErrorMessage = ex.Message;
            }
            return View(s3Bucket);
        }

        public async Task<IActionResult> DownloadFile(string BucketName, string FileName)
        {
            try
            {
                Amazon.S3.Model.GetObjectResponse res = await client.DownloadFile(FileName, BucketName);
                return File(res.ResponseStream, res.Headers["Content-Type"], FileName);
            }
            catch (Exception ex)
            {
                var allBukcets = await client.GetBucketsAsync();
                ViewBag.Buckets = allBukcets.Select(x => new SelectListItem()
                {
                    Text = x.BucketName,
                    Value = x.BucketName
                });

                ViewBag.ErrorMessage = ex.Message;
                return View("Index");
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new Models.ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
