using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AWS_S3.AWS_S3_Helper.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using AWS.S3.DataAccess;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using AWS_S3.Middleware;
using AWS_S3.Services;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;
using Swashbuckle.AspNetCore.Filters;
using AWS_S3.Models.RequestResponseExample;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Diagnostics;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;

namespace AWS_S3
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment hostingEnv)
        {
            config = configuration;
            env = hostingEnv;            
        }

        public IConfiguration config { get; }
        public IWebHostEnvironment env { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContextPool<AppDbContext>(options => options.UseSqlServer(config.GetConnectionString("ConStr")));
            services.AddIdentity<ApplicationUser, IdentityRole>(

            ).AddEntityFrameworkStores<AppDbContext>();

            //services.AddControllersWithViews();
           services.AddMvc();
            //services.AddMvc(options => options.EnableEndpointRouting = false).SetCompatibilityVersion(CompatibilityVersion.Latest);

            //services.AddApiVersionWithExplorer();

            //services.AddSwaggerExamplesFromAssemblyOf<AddTagReqExample>();

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = config.GetSection("SwaggerInfo").GetSection("Title").Value,
                    Version = "v1",
                    Description = config.GetSection("SwaggerInfo").GetSection("Description").Value,
                    //TermsOfService = new Uri(config.GetSection("SwaggerInfo").GetSection("TermsOfService").Value)
                    //,
                    //License = new OpenApiLicense() { Name = config.GetSection("SwaggerInfo").GetSection("License").GetSection("Name").Value, Url = new Uri(config.GetSection("SwaggerInfo").GetSection("License").GetSection("Url").Value) }
                    //,
                    Contact = new OpenApiContact()
                    {
                        Name = config.GetSection("SwaggerInfo").GetSection("Contact").GetSection("Name").Value,
                        Email = config.GetSection("SwaggerInfo").GetSection("Contact").GetSection("Email").Value
                        //Url = new Uri(config.GetSection("SwaggerInfo").GetSection("Contact").GetSection("Url").Value)
                    }
                });

                c.ExampleFilters();

                c.DocumentFilter<YamlDocumentFilter>();
                c.OperationFilter<AddRequiredHeaderParameter>();

                // Use method name as operationId
                c.CustomOperationIds(apiDesc =>
                {
                    return apiDesc.TryGetMethodInfo(out MethodInfo methodInfo) ? methodInfo.Name : null;
                });

                c.EnableAnnotations();
                //c.DescribeAllEnumsAsStrings();

                //c.OrderActionsBy((apiDesc) => $"{apiDesc.ActionDescriptor.RouteValues["controller"]}_{apiDesc.HttpMethod}");
                //c.TagActionsBy(api => api.HttpMethod);

                //c.CustomSchemaIds((type) => type.FullName);


                // Define the OAuth2.0 scheme that's in use (i.e. Implicit Flow)
                c.AddSecurityDefinition("Authorization", new OpenApiSecurityScheme
                {
                    Type = SecuritySchemeType.ApiKey,
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Description = "Use your **clientId** and **clientSecret** key to generate Authorization Token from Oauth2 API. <br><br> OAuth2 API Specs can be found in Fiber Portal under **Private => Internal** Category."
                });

                c.AddSecurityDefinition("x-api-key", new OpenApiSecurityScheme
                {
                    Type = SecuritySchemeType.ApiKey,
                    Name = "x-api-key",
                    In = ParameterLocation.Header,
                    Description = "Token that needs to provide when making API calls."
                });


                ////Set the comments path for the Swagger JSON and UI.
                //var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
                //var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                //c.IncludeXmlComments(xmlPath, includeControllerXmlComments: true);
            });

            //services.AddSwaggerExamplesFromAssemblyOf<AddTagReqExample>();
            //services.AddSwaggerExamplesFromAssemblyOf<DownloadFileExample>();
            //services.AddSwaggerExamplesFromAssemblyOf<GetAccessTokenResExample>();
            services.AddSwaggerExamplesFromAssemblyOf<GlobalSearchReqExample>();
            

            services.AddTokenAuthentication(config);
            services.AddSingleton<IAwsClient, AwsClient>();
            //services.AddTransient<ApiLogService>();


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}
            //else
            //{
            //    app.UseDeveloperExceptionPage();

            //    //app.UseExceptionHandler("/Home/Error");
            //    //// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            //    //app.UseHsts();
            //}

            //app.UseExceptionHandler(a => a.Run(async context =>
            //{
            //    var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
            //    var exception = exceptionHandlerPathFeature.Error;

            //    var result = JsonConvert.SerializeObject(new { message = exception.Message });
            //    context.Response.ContentType = "application/json";
            //    await context.Response.WriteAsync(result);
            //}));

            app.UseHttpsRedirection();

            app.UseMiddleware<ApiLoggingMiddleware>();

            app.UseStaticFiles();
            app.UseStaticFiles(new StaticFileOptions
            {
                ServeUnknownFileTypes = true,
                DefaultContentType = "application/yaml",
            });

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            //app.UseSwagger();
            app.UseSwagger(c =>
            {
                //c.RouteTemplate = "/" + "{documentName}/swagger.json";

                c.PreSerializeFilters.Add((swagger, httpReq) =>
                {
                    swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"{httpReq.Scheme}://{httpReq.Host.Value}", Description = (env.IsDevelopment() ? "UAT" : "UAT") + " DMS API" } };
                    //swagger.Servers = new List<OpenApiServer> {
                    //    new OpenApiServer{ Url="https://devapi.edelweissfin.com" , Description="Development URL"},
                    //    new OpenApiServer{ Url="https://apis.edelweissfin.com" , Description="Production URL"}
                    //};

                });
            });

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                //provider
                //.ApiVersionDescriptions
                //.ToList()
                //.ForEach(description =>
                //{
                //    c.SwaggerEndpoint(
                //        $"/{description.GroupName}/swagger.json",
                //        description.GroupName.ToUpperInvariant());
                //});

                c.SwaggerEndpoint("/swagger/v1/swagger.json", "DMS API v1");
            });

            app.UseRouting();

            app.UseAuthentication();
            //app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
