﻿using AWS.S3.DataAccess;
using AWS_S3.Services;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS_S3.Middleware
{
    public class ApiLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private ApiLogService _apiLogService;

        public ApiLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            try
            {
                var request = httpContext.Request;
                if (request.Path.StartsWithSegments(new PathString("/api")))
                {
                    var stopWatch = System.Diagnostics.Stopwatch.StartNew();
                    var requestTime = DateTime.UtcNow;
                    var requestBodyContent = await ReadRequestBody(request);

                    await _next(httpContext);
                    stopWatch.Stop();

                    string responseBodyContent = string.Empty;
                    await SafeLog(requestTime,
                        stopWatch.ElapsedMilliseconds,
                        httpContext.Response.StatusCode,
                        request.Method,
                        request.Path,
                        request.QueryString.ToString(),
                        requestBodyContent,
                        responseBodyContent);

                    //var originalBodyStream = httpContext.Response.Body;
                    //using (var responseBody = new System.IO.MemoryStream())
                    //{
                    //    var response = httpContext.Response;
                    //    response.Body = responseBody;
                    //    await _next(httpContext);
                    //    stopWatch.Stop();

                    //    string responseBodyContent = null;
                    //    responseBodyContent = await ReadResponseBody(response);
                    //    await responseBody.CopyToAsync(originalBodyStream);

                    //    //    await SafeLog(requestTime,
                    //    //        stopWatch.ElapsedMilliseconds,
                    //    //        response.StatusCode,
                    //    //        request.Method,
                    //    //        request.Path,
                    //    //        request.QueryString.ToString(),
                    //    //        requestBodyContent,
                    //    //        responseBodyContent);

                    //}
                }
                else
                {
                    await _next(httpContext);
                }
            }
            catch (Exception ex)
            {
                await _next(httpContext);
            }
        }

        private async Task<string> ReadRequestBody(HttpRequest request)
        {
            HttpRequestRewindExtensions.EnableBuffering(request);



            var buffer = new byte[Convert.ToInt32(request.ContentLength)];
            await request.Body.ReadAsync(buffer, 0, buffer.Length);
            var bodyAsText = System.Text.Encoding.UTF8.GetString(buffer);
            request.Body.Seek(0, System.IO.SeekOrigin.Begin);

            return bodyAsText;
        }
        private async Task<string> ReadResponseBody(HttpResponse response)
        {
            response.Body.Seek(0, System.IO.SeekOrigin.Begin);
            var bodyAsText = await new System.IO.StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, System.IO.SeekOrigin.Begin);

            return bodyAsText;
        }

        private async Task SafeLog(DateTime requestTime,
                            long responseMillis,
                            int statusCode,
                            string method,
                            string path,
                            string queryString,
                            string requestBody,
                            string responseBody)
        {
            if (path.ToLower().StartsWith("/api/login"))
            {
                requestBody = "(Request logging disabled for /api/login)";
                responseBody = "(Response logging disabled for /api/login)";
            }

            if (requestBody.Length > 100)
            {
                requestBody = $"(Truncated to 100 chars) {requestBody.Substring(0, 100)}";
            }

            if (responseBody.Length > 100)
            {
                responseBody = $"(Truncated to 100 chars) {responseBody.Substring(0, 100)}";
            }

            if (queryString.Length > 100)
            {
                queryString = $"(Truncated to 100 chars) {queryString.Substring(0, 100)}";
            }

            bool resLog = DMS_Models.LogToFile.LogRequest(new DMS_Models.LogToFile.ApiLogItem1
            {
                RequestTime = requestTime,
                ResponseMillis = responseMillis,
                StatusCode = statusCode,
                Method = method,
                Path = path,
                QueryString = queryString,
                RequestBody = requestBody,
                ResponseBody = responseBody
            });

            
        }
    }
}
