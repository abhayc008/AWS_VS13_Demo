﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace AWS.S3.DataAccess
{
    public class ApplicationUser : IdentityUser
    {
        public string AWS_AccessKey { get; set; }
        public string AWS_SecretKey { get; set; }
        public string AWS_Bucket { get; set; }

        public string AWS_BucketFolder { get; set; }
    }
}
