﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AWS.S3.DataAccess.Migrations
{
    public partial class IitialMigation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
