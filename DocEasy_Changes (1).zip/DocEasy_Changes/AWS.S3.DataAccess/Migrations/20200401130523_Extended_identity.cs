﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AWS.S3.DataAccess.Migrations
{
    public partial class Extended_identity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AWS_AccessKey",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AWS_Bucket",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AWS_SecretKey",
                table: "AspNetUsers",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AWS_AccessKey",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "AWS_Bucket",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "AWS_SecretKey",
                table: "AspNetUsers");
        }
    }
}
