﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AWS.S3.DataAccess.Migrations
{
    public partial class ExtendIdentity_BucketFolder : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AWS_BucketFolder",
                table: "AspNetUsers",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AWS_BucketFolder",
                table: "AspNetUsers");
        }
    }
}
